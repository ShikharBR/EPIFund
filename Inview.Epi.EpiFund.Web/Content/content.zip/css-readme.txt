
How to add to CSS:

--------------------------------------------

Assuming you have Ruby and Sass installed..

1. Open a command window in Content/

2. Type 'sass --watch style.scss:Site.css'

3. Edit only style.scss

--------------------------------------------

Learn more about Sass: http://sass-lang.com/